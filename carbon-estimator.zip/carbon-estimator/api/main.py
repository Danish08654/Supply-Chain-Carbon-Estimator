import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from schema import ProcurementItem, EmissionResult
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors as rl_colors
from reportlab.lib.units import cm
from datetime import datetime
import tempfile, os

app = FastAPI(
    title="Supply Chain Carbon Estimator",
    description="Scope 3 emission estimation and ESG report generation",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Load at startup
carbon_model  = xgb.XGBRegressor()
carbon_model.load_model("carbon_model.json")

le_cat        = joblib.load("le_category.joblib")
le_subcat     = joblib.load("le_subcategory.joblib")
le_country    = joblib.load("le_country.joblib")
le_transport  = joblib.load("le_transport.joblib")
le_supplier   = joblib.load("le_supplier.joblib")
ef_df         = joblib.load("emission_factors.joblib")

with open("carbon_metadata.json") as f:
    metadata = json.load(f)

FEATURES = metadata["features"]


def safe_encode(encoder, value, classes_list):
    if value in classes_list:
        return int(encoder.transform([value])[0])
    return 0


def calculate_risk_score(co2_per_kg, has_iso14001, has_cdp_rating,
                          country, transport_mode, renewable_pct):
    country_mult = {"China":1.2,"USA":1.0,"Germany":0.7,"India":1.4,
                    "Vietnam":1.3,"Bangladesh":1.5,"Brazil":0.6,
                    "Mexico":0.9,"South Korea":0.85,"Taiwan":0.95}.get(country, 1.0)
    score = min(100,
        co2_per_kg * 10
        + (1 - has_iso14001) * 15
        + (1 - has_cdp_rating) * 10
        + country_mult * 10
        + (transport_mode == 'Air Freight') * 20
        + (100 - renewable_pct) * 0.2
    )
    return round(score, 2)


def get_esg_tier(risk_score, iso14001_rate):
    if risk_score < 30 and iso14001_rate > 0.4:
        return "Green"
    elif risk_score < 60:
        return "Yellow"
    return "Red"


def get_reduction_actions(req: ProcurementItem, risk_score: float):
    actions = []
    potential = 0.0

    if req.transport_mode == 'Air Freight':
        actions.append("Switch to Sea Freight — reduces transport emissions by up to 97%")
        potential += 25.0
    if req.renewable_pct < 50:
        actions.append(f"Increase supplier renewable energy from {req.renewable_pct:.0f}% to 80%+")
        potential += 15.0
    if not req.has_iso14001:
        actions.append("Require ISO 14001 environmental certification from supplier")
        potential += 12.0
    if not req.has_cdp_rating:
        actions.append("Engage supplier in CDP climate disclosure programme")
        potential += 8.0
    if req.supplier_country in ['Bangladesh', 'India', 'Vietnam', 'China']:
        actions.append("Explore nearshoring to reduce transport distance and carbon intensity")
        potential += 10.0

    return actions[:4], round(min(potential, 60.0), 1)


@app.get("/")
def root():
    return {
        "service": "Supply Chain Carbon Estimator",
        "version": metadata["version"]
    }


@app.post("/estimate", response_model=EmissionResult)
def estimate_emissions(req: ProcurementItem):
    try:
        X = pd.DataFrame([{
            'category_enc':    safe_encode(le_cat, req.category, metadata['categories']),
            'subcategory_enc': safe_encode(le_subcat, req.subcategory, metadata['subcategories']),
            'country_enc':     safe_encode(le_country, req.supplier_country, metadata['countries']),
            'transport_enc':   safe_encode(le_transport, req.transport_mode, metadata['transports']),
            'supplier_enc':    safe_encode(le_supplier, req.supplier_type, metadata['supplier_types']),
            'quantity_kg':     req.quantity_kg,
            'distance_km':     req.distance_km,
            'renewable_pct':   req.renewable_pct,
            'has_iso14001':    req.has_iso14001,
            'has_cdp_rating':  req.has_cdp_rating,
            'supplier_age_yrs':req.supplier_age_yrs,
        }])

        predicted_co2 = float(carbon_model.predict(X[FEATURES])[0])
        predicted_co2 = max(0, predicted_co2)
        co2_per_kg    = predicted_co2 / max(req.quantity_kg, 1)

        risk_score    = calculate_risk_score(
            co2_per_kg, req.has_iso14001, req.has_cdp_rating,
            req.supplier_country, req.transport_mode, req.renewable_pct
        )
        esg_tier      = get_esg_tier(risk_score, req.has_iso14001)
        actions, reduction_pct = get_reduction_actions(req, risk_score)

        return EmissionResult(
            company_name=req.company_name or "Unknown",
            category=req.category,
            subcategory=req.subcategory,
            supplier_country=req.supplier_country,
            transport_mode=req.transport_mode,
            quantity_kg=req.quantity_kg,
            predicted_co2_kg=round(predicted_co2, 3),
            co2_per_kg=round(co2_per_kg, 4),
            carbon_risk_score=risk_score,
            esg_tier=esg_tier,
            top_reduction_actions=actions,
            estimated_reduction_potential_pct=reduction_pct
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/factors")
def emission_factors():
    return ef_df.to_dict(orient='records')


@app.get("/model/info")
def model_info():
    return metadata