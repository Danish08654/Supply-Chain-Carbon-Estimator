from pydantic import BaseModel, Field
from typing import Optional

class ProcurementItem(BaseModel):
    category:         str   = Field(..., description="Raw Materials | Manufacturing | Logistics | Energy | Services")
    subcategory:      str   = Field(..., description="e.g. Steel, Electronics, Air Freight")
    supplier_country: str   = Field(..., description="Supplier country name")
    supplier_type:    str   = Field(..., description="Tier 1 | Tier 2 | Tier 3")
    transport_mode:   str   = Field(..., description="Sea Freight | Air Freight | Road Freight | Rail Freight")
    quantity_kg:      float = Field(..., gt=0, description="Quantity in kg")
    distance_km:      float = Field(..., gt=0, description="Shipping distance in km")
    renewable_pct:    float = Field(..., ge=0, le=100, description="Supplier renewable energy %")
    has_iso14001:     int   = Field(..., ge=0, le=1, description="ISO 14001 certified")
    has_cdp_rating:   int   = Field(..., ge=0, le=1, description="CDP rated supplier")
    supplier_age_yrs: int   = Field(..., ge=0, description="Years supplier has been operating")
    company_name:     Optional[str] = "My Company"

class EmissionResult(BaseModel):
    company_name:       str
    category:           str
    subcategory:        str
    supplier_country:   str
    transport_mode:     str
    quantity_kg:        float
    predicted_co2_kg:   float
    co2_per_kg:         float
    carbon_risk_score:  float
    esg_tier:           str
    top_reduction_actions: list
    estimated_reduction_potential_pct: float